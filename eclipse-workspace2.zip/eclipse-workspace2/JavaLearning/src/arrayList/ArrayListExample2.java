package arrayList;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		ArrayList<Integer> list = new ArrayList<>();

	}

}
