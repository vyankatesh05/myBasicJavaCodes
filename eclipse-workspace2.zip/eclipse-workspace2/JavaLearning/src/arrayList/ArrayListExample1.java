 
package arrayList;
import java.util.*;
public class ArrayListExample1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		//ArrayList Syntax
		//ArrayList<Datatype> name = new ArrayList<>();
		ArrayList<Integer> list = new ArrayList<>();
//		list.add(11);
//		list.add(2);
//		list.add(33);
//		list.add(44);
//		list.add(55);
//		list.add(66);
//		System.out.println(list);
//		
//		list.set(1, 99);
//		System.out.println(list);
//		
//		list.remove(2);
//		System.out.println(list);
		
		//Add elements using for loop
		for (int i = 0; i < 5; i++) {
			list.add(sc.nextInt());
		}
		
		//get item at any index using get
		for (int i = 0; i < 5; i++) {
			System.out.print(list.get(i)+ " "); //pass index here , get() is used to get element  
		}
		
		
		
		
		
		
		
//		int[][] arr = {
//				{1,2,3,4},
//				{5,6},
//				{7,8,9},
//			};
//		
//		for(int row = 0; row < arr.length; row++) {
//			for(int col = 0; col<arr[row].length; col++){
//				System.out.print(arr[row][col]+ " ");
//			} 
//			System.out.println();
//		}
		
	}

}
