package linkedin;

public class Ticket {
	
	public Ticket() {}
	
	private String destination;
	private double price;
	private boolean isReturn;
	
	public String getDestination() {
		return destination;
	}



	public void setDestination(String destination) {
		this.destination = destination;
	}



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	public boolean isReturn() {
		return isReturn;
	}



	public void setReturn(boolean isReturn) {
		this.isReturn = isReturn;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Ticket t1 = new Ticket();
		t1.setDestination("USA");
		t1.setPrice(5000.552f);
		t1.setReturn(true);
		
		System.out.println("Destination is: "+t1.getDestination()+" "+"Travelling cost is: "+t1.getPrice()+" "+"True/False: "+t1.isReturn);

	}

}
