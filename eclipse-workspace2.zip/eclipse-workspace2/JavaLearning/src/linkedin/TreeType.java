package linkedin;

public enum TreeType {
		OAK,
		MAPLE,
		WALNUT,
		STRAWBERRY,
		MANGO,
		BANANA;
}
