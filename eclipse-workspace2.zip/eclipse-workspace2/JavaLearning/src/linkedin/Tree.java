package linkedin;

public class Tree {
	double height;
	double trunkDiameter;
	TreeType treeType;
	
	Tree(double height, double trunkDiameter, TreeType treeType){
		this.height = height;
		this.trunkDiameter = trunkDiameter;
		this.treeType = treeType;
	}
	void grow() {
		this.height = this.height+10;
		this.trunkDiameter = this.trunkDiameter+1;
	}
	
	public static void main(String args[]) {
	Tree MyTree1 = new Tree(225,20,TreeType.MANGO);
	System.out.println(MyTree1.treeType);
	
	Tree MyTree2 = new Tree(50, 10, TreeType.OAK);
	
	if(MyTree1.height > 100) {
		System.out.println("That's tall " +MyTree1.treeType+" tree of height "+MyTree1.height);
	}
	
	if(MyTree2.height < 100) {
		System.out.println("That's small "+MyTree2.treeType+" tree of height "+MyTree2.height);
	}
	
	}
}
