package FileInputOutput;
import java.io.*;
public class DisplayFileInformation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File f = new File("C:\\Users\\Vyankatesh\\Desktop\\FileDemoExample\\Demo.txt");
		if(f.exists()) {
			System.out.println("File name: "+f.getName());
			System.out.println("File location: "+f.getAbsolutePath());
			System.out.println("file witable: "+f.canWrite());
			System.out.println("File readable: "+f.canRead());
			System.out.println("File size: "+f.length());
		}
		else {
			System.out.println("No information available");
		}
	}

}
