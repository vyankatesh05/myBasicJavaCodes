package FileInputOutput;
import java.io.*;
public class RenameExistingFile {

	public static void main(String[] args) throws IOException {
		// First create file in folder
		File f = new File("C:\\Users\\Vyankatesh\\Desktop\\FileDemoExample\\BeforeRename.txt");
		if(f.createNewFile()) {
			System.out.println("File created");
		}
		else
		{
			System.out.println("file is not created");
		}
		
		//Write in same file
		FileWriter fw = new FileWriter(f);
		fw.write("This is file handling in java , We're going to change name of the file");
		fw.close();
		
		//read data in the file
		FileReader fr = new FileReader(f);
		int i;
		while((i=fr.read())!=-1)
		{
			System.out.print((char)i);
		}
		fr.close();
		
		//rename file
		File file = new File("C:\\Users\\Vyankatesh\\Desktop\\FileDemoExample\\AfterRename.txt");
		if(f.exists())
		{
			System.out.println(f.renameTo(file));
		}
		else {
			System.out.println("File DNE");
		}
	}

}
