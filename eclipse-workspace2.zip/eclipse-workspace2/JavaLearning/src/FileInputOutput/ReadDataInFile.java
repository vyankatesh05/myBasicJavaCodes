package FileInputOutput;
import java.io.*;
public class ReadDataInFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileReader fr = new FileReader("C:\\Users\\Vyankatesh\\Desktop\\FileDemoExample\\Demo.txt");
		
		int i;
		while((i = fr.read())!=-1) {
			System.out.print((char)i);
		}
		fr.close();
	}

}
