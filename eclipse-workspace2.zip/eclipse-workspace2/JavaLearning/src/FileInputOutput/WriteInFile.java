package FileInputOutput;
import java.io.*;
public class WriteInFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f = new File("C:\\Users\\Vyankatesh\\Desktop\\FileDemoExample\\Demo.txt");
		FileWriter fw = new FileWriter(f);
		fw.write("This is written using filewriter method");
		fw.close();
	}

}
