/*Create a superclass called "Shape" with a method called "calculateArea()". 
 * Create two subclasses called "Circle" and "Rectangle" that extend the "Shape" class 
 * and implement their own versions of the "calculateArea()" method.*/

package inheritance;

class Shape {
	public void calculateArea() {
		System.out.println("This method calcultes area");
	}
}

class Circle extends Shape{
	public void calculateArea(){
		double r = 5;
		final double p = 3.14;
		
		double circle = p * r * r ;
		System.out.println("Area of circle is: "+circle);
	}

}

class Rectangle extends Shape{

	public void calculateArea() {
		double l = 5 , b = 5 , area;
		area = l * b ;
		System.out.println("Area of rectangle is: "+area);
	}
} 


public class AreaExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s = new Shape();
		s.calculateArea();
		
		Circle c = new Circle();
		c.calculateArea();
		
		Rectangle r = new Rectangle();
		r.calculateArea();

	}

}
