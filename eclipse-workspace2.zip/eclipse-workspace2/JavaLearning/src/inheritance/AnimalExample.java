//Create a superclass called "Animal" with a method called "makeSound()". Create three subclasses called "Cat," "Dog," and "Cow" that extend the "Animal" class and provide their own implementation of the "makeSound()" method.
package inheritance;
class Animals{
	public void makeSound(){
		System.out.println("Each animal have different sound");
	}
}

class Cat extends Animals{
	public void makeSound() {
		System.out.println("Sound method of Cat");
	}
}

class Dogs extends Animals{
	public void makeSound() {
		System.out.println("Sound method of Dog");
	}
}

class Cow extends Animals{
	public void makeSound() {
		System.out.println("Sound method  of Cow");
	}
}

public class AnimalExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cow cow = new Cow();
		cow.makeSound();
		
		Dogs dog = new Dogs();
		dog.makeSound();
		
		Cat cat = new Cat();
		cat.makeSound();
		
		Animals animal = new Animals();
		animal.makeSound();

	}

}
