/*Create a superclass called "Animal" with a method called "eat()". 
 * Create a subclass called "Dog" that extends the "Animal" class 
 * and overrides the "eat()" method to print "The dog is eating."*/

package inheritance;

class Animal{
	public void eat() {
		System.out.println("Animal is eating");
	}
}

class Dog extends Animal{
	public void eat() {
		System.out.println("Dog is eating");
	}
}

public class DogExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal animal = new Animal();
		animal.eat();
		
		Dog dog = new Dog();
		dog.eat();
		
	}

}
