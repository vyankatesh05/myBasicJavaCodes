//Create a superclass called "Vehicle" with a method called "startEngine()". Create two subclasses called "Car" and "Motorcycle" that extend the "Vehicle" class and provide their own implementation of the "startEngine()" method.
package inheritance;

class Vehicle {
	public void startEngine() {
		System.out.println("Engine start");
	}
}

class Car extends Vehicle{
	public void startEngine() {
		System.out.println("Car's engine started");
	}
}

class Motorcycle extends Vehicle{
	public void startEngine() {
		System.out.println("Motorcycle's engine started");
	}
}

public class VehicleExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle v =  new Vehicle();
		v.startEngine();
		
		Car c = new Car();
		c.startEngine();
		
		Motorcycle m = new Motorcycle();
		m.startEngine();
	}

}
