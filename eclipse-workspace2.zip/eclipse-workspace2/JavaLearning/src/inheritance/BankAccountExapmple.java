//Create a superclass called "BankAccount" with instance variables "accountNumber" and "balance". Create a subclass called "SavingsAccount" that extends the "BankAccount" class and adds an instance variable "interestRate" and methods to deposit and withdraw money.

package inheritance;

class BankAccount {
	protected double accountNumber;
	protected double balance;
	
	BankAccount(double accountNumber, double balance){
		this.accountNumber = accountNumber;
		this.balance = balance;
	}
	
	public void displayInfo() {
		System.out.println("Account number is: "+accountNumber);
		System.out.println("Balance is: "+balance);
	}
	
}

class SavingsAccount extends BankAccount{
	private double interestRate;
	SavingsAccount(double accountNumber, double balance, double interestRate){
		super(accountNumber, balance);
		this.accountNumber = accountNumber;
		this.balance = balance;
		this.interestRate = interestRate;
	}
	
	public void displayInfos() {
		System.out.println("Account number is: "+accountNumber);
		System.out.println("Balance is: "+balance);
		System.out.println("Interest rate: "+interestRate);
	}
}

public class BankAccountExapmple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount ba = new BankAccount(1001,550.5);
		ba.displayInfo();
		
		SavingsAccount sa = new SavingsAccount(10032,975120,5);
		sa.displayInfo();
	}

}
