//Create a superclass called "Employee" with instance variables "empId" and "empName". Create two subclasses called "Manager" and "Worker" that extend the "Employee" class and add their own specific instance variables and methods.

package inheritance;

class Employees{
	protected int empId;
	protected String empName;
	
	Employees(int empId, String empName){
		this.empId = empId;
		this.empName = empName;
	}
	
	public void displayInfo() {
		System.out.println("Employee Id is: "+empId);
		System.out.println("Employee Name is: "+empName);
	}
}

class Manager extends Employees{
	private String department;
	Manager(int empId, String empName, String department) {
		super(empId, empName);
		this.department = department;
	}
	public void displayInfo() {
		System.out.println("Manager Id is: "+empId);
		System.out.println("Manager Name is: "+empName);
		System.out.println("Department of manager is"+department);
	}
}

class Worker extends Employees{
	private int salary;
	Worker(int empId, String empName, int salary) {
		super(empId, empName);
		// TODO Auto-generated constructor stub
		this.salary = salary;
	}
	public void displayInfo() {
		System.out.println("Worker Id is: "+empId);
		System.out.println("Worker Name is: "+empName);
		System.out.println("Salary of worker is"+salary);
	}
}

public class EmployeeExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employees emp = new Employees(101,"ABC");
		emp.displayInfo();
		
		Manager manager = new Manager(102,"PQR", "Testing");
		manager.displayInfo();
		
		Worker worker = new Worker(103,"XYZ",2000);
		worker.displayInfo();
	}

}
