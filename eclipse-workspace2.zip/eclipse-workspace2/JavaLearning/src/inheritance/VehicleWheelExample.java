//Create a superclass called "Vehicle" with instance variables "color" and "numberOfWheels". Create two subclasses called "Car" and "Bicycle" that extend the "Vehicle" class and add their own specific instance variables and methods.

package inheritance;

class Vehicles{
	protected String color;
	protected int numberOfWheels;
	
	Vehicles( String color, int numberOfWheels){
		this.color = color;
		this.numberOfWheels = numberOfWheels;
	}
	
	public void displayInfo() {
		System.out.println("Color of Vehicle is: "+color);
		System.out.println("Wheels: "+numberOfWheels);
	}
}

class Cars extends Vehicles{
	private int noOfDoors;
	Cars(String color, int numberOfWheels, int noOfDoors) {
		super(color, numberOfWheels);
		// TODO Auto-generated constructor stub
		this.noOfDoors = noOfDoors;
	}
	
	public void displayInfo() {
		System.out.println("Color of Car is: "+color);
		System.out.println("Wheels: "+numberOfWheels);
		System.out.println("No of doors car have: "+noOfDoors);
	}
	
	public void Engine() {
		System.out.println("Engine starts");
	}
}

class Bicycles extends Vehicles{
	private boolean hasBasket;
	Bicycles(String color, int numberOfWheels, boolean hasBasket){
		super(color, numberOfWheels);
		this.hasBasket = hasBasket;
	}
	public void displayInfo() {
		System.out.println("Color of Bicycle is: "+color);
		System.out.println("Wheels: "+numberOfWheels);
		System.out.println("Basket is available?: "+hasBasket);
	}
	
	public void ringBell() {
		System.out.println("Biycle has ring");
	}
}

public class VehicleWheelExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicles v = new Vehicles("Black", 4);
		v.displayInfo();
		
		Cars c = new Cars("White", 4, 4);
		c.displayInfo();
		
		Bicycles b = new Bicycles("Red",2,true);
		b.displayInfo();
	}

}
