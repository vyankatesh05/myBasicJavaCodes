//Create a superclass called "Shape" with a method called "draw()". Create three subclasses called "Circle," "Rectangle," and "Triangle" that extend the "Shape" class and provide their own implementation of the "draw()" method.

package inheritance;

class Shapes{
	public void Draw() {
		System.out.println("this is common draw method for all classes and all shapes");
	}
}

class Circles extends Shapes{
	public void DrawCircle() {
		System.out.println();
		System.out.println("this is draw method of circles class");
	}
}

class Rectangles extends Shapes{
	public void DrawRectangles() {
		System.out.println();
		System.out.println("this is draw method of rectangle class");
	}
}

class Triangles extends Shapes{
	public void DrawTriangles() {
		System.out.println();
		System.out.println("this is draw method of triangles class");
	}
}

public class ShapeExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangles tr = new Triangles();
		tr.Draw();
		tr.DrawTriangles();
		
		Rectangles rr = new Rectangles();
		rr.Draw();
		rr.DrawRectangles();
		
		Circles cr = new Circles();
		cr.Draw();
		cr.DrawCircle();
	}

}
