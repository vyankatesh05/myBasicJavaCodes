/*Create a superclass called "Person" with instance variables "name" and "age". Create a subclass called "Employee" that extends the "Person" class and adds an instance variable "salary"*/

package inheritance;
class Person {
	protected String name;
	protected int age;
	
	Person(String name, int age){
		this.name = name;
		this.age = age;
	}
	
	public void displayInfo() {
		System.out.println("Name is: "+name+" age is:"+age);
	}
}

class Employee extends Person{
	private double salary;
	Employee(String name, int age, double salary) {
		super(name, age);
		// TODO Auto-generated constructor stub
		this.name = name;
		this.age = age;
		this.salary = salary;
		
	}
	public void displayInfo() {
		System.out.println("Name="+name+" "+"age="+age+" "+"salary="+salary);
	}
}

public class PersonEployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p = new Person("ABC",22);
		p.displayInfo();
		
		Employee e = new Employee("XYZ",22, 50000.15);
		e.displayInfo();
	}

}
