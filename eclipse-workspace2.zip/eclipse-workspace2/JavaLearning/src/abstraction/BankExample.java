//Create an abstract class called Bank with abstract methods deposit() and withdraw(). Create subclasses SavingsAccount and CurrentAccount that inherit from Bank and implement the deposit() and withdraw() methods.

package abstraction;

public class BankExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
