package exception;

public class ExceptionHandleExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int[] myarr = {10, 20, 30, 40};
			System.out.println(myarr[4]);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Exception Handling");
	}

}
