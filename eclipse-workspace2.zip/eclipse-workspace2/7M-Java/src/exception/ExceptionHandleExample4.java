package exception;

public class ExceptionHandleExample4 {


	    public static void main(String[] args) {
	        try
	        {
	            int a=10/0;
	            System.out.println(a);
	        }
	        finally //finally block always executes
	        {
	            System.out.println("finally block executed");
	        }
	        System.out.println("after finally");//since exception is not caught hence program terminating after finally block
	    }
	}


