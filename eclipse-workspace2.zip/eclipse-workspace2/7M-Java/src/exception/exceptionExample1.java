package exception;

public class exceptionExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a =10/0;
		System.out.println(a); // o/p -----> java.lang.ArithmeticException: / by zero
		
		int[] arr = {1, 23, 4};	 //this part is not getting executed (even if correct) because above code has exception and it will terminate code
		for (int i = 0; i <3; i++) {
			System.out.println(arr[i]);
		}

		String s11 = null; 	// o/p ------->java.lang.NullPointerException: Cannot invoke "String.length()" because "s11" is null
		System.out.println(s11.length());
		
		String s1 = "Hello";
		int i1 = Integer.parseInt(s1);  //o/p----------> java.lang.NumberFormatException: For input string: "Hello"

	}

}
