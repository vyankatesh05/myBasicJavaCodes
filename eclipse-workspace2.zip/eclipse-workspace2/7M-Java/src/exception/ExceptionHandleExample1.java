package exception;

public class ExceptionHandleExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//int a = 10/0;
			String s11 = null; 	// o/p if not handled------->java.lang.NullPointerException: Cannot invoke "String.length()" because "s11" is null
			System.out.println(s11.length());
		}
		
		catch(Exception e) {
		//	System.out.println("Cannot divide by zero "+ e); //Cannot divide by zerojava.lang.ArithmeticException: / by zero
			System.out.println("Null String "+ e);  //Null String java.lang.NullPointerException: Cannot invoke "String.length()" because "s11" is null
		}
	}

}
