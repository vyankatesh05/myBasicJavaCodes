package exception;

public class ThrowDemo {
	void checkVotingEligibility(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("Not eligible for voting");
		}
		else {
			System.out.println("Eligible to cast vote");
		}
	}
	
	
	public static void main(String[] args) {
		ThrowDemo obj = new ThrowDemo();
		obj.checkVotingEligibility(12);
	}

}
