package exception;

public class ExceptionHandleExample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      try {
	          int myarr[]=new int[5];
	          myarr[5]=10/2;
	          }
	          catch(ArithmeticException e)
	          {
	              System.out.println("Number divide by zero exception");
	              
	          }
	          catch(ArrayIndexOutOfBoundsException e)
	          {
	              System.out.println(e);
	          }
	          catch(Exception e)	//if we write this catch block first , it will give error because this catch block is most generous so it will compile but it will not go to next catch boxes because (Excepion e) catch block is most generous than others
	          {
	              System.out.println(e);
	          }
	          System.out.println("Exception handled");
	      }
	}


