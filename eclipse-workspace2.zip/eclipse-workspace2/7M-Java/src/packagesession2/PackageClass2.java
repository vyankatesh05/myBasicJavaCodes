package packagesession2;

import packagesession.*;	//previous package declaration
//import packagesession.PackageClass;

public class PackageClass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PackageClass obj = new PackageClass();
		obj.m1();

	}

}
