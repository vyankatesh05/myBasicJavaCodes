package fileIO;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
			//create file and add data to the file
		FileOutputStream fos = new FileOutputStream("Employee.txt");
		String empdata = "Empno: 111 Name: ABC City: Pune";
		byte b[]=empdata.getBytes();
		

			//read data from file
		FileInputStream fis = new FileInputStream("Employee.txt");
		BufferedInputStream bis = new BufferedInputStream(fis);
		int data;
		while((data=bis.read())!=-1) {
			System.out.print((char)data);
		}
		bis.close();
		fis.close();
		fos.write(b);
		fos.close();
	}
		
	

}
