package fileIO;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class FileInputStreamDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream fis = new FileInputStream("Course.txt");
		BufferedInputStream bis = new BufferedInputStream(fis);
		int data;
		while((data=bis.read())!=-1) {
			System.out.print((char)data);
		}
		bis.close();
		fis.close();
	}

}
