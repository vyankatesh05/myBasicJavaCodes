package fileIO;
import java.io.*;
public class FileDemo2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		File f = new File("Student.txt");
		FileWriter fw = new FileWriter(f);
		fw.write("Learning file input output");
		fw.close();
	}

}
