package fileIO;
import java.io.*;
import java.util.*;
public class FileDemo3 {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		File f = new File("Student.txt");
		
		Scanner sc = new Scanner(f);
		while(sc.hasNextLine())
		{
			String data = sc.nextLine();
			System.out.println(data);
		}
		sc.close();
	}

}
