package fileIO;
import java.io.*;

public class FileDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File f = new File("Student.txt");
		if(f.exists()) {
			System.out.println("File already exists");
			System.out.println("File path: "+f.getPath());
			System.out.println("File path: "+f.getAbsolutePath());

		}
		else
		{
			f.createNewFile();
			System.out.println("File created");
		}
	}

}
