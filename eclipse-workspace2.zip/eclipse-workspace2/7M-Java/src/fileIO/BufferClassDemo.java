package fileIO;
import java.io.*;
public class BufferClassDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileOutputStream fos = new FileOutputStream("Course.txt");
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		String data = "Java backend course";
		byte b[]=data.getBytes();
		bos.write(b);
	    bos.flush();	
	    bos.close();
	    fos.close();
	}

}
