package string;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer("Hello");
		sb.append(" Good Afternoon");
		sb.replace(0, 4, "V");
		System.out.println(sb);
		
		StringBuffer sb2 = new StringBuffer("Hello World!");
		sb2.append(" Welcome");
		System.out.println(sb2.delete(1, 5));
		System.out.println(sb2.reverse());
		
	}

}
