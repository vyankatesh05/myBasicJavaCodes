package serialization;
import java.io.*;
class Product implements Serializable{
	int product_id;
	String product_name;
	public Product(int product_id, String product_name) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
	}
	
}

public class ProductSerialization {

	public static void main(String[] args) throws IOException {
		Product p = new Product(100,"Laptop");
		FileOutputStream fos = new FileOutputStream("Product.txt");
		ObjectOutputStream os = new ObjectOutputStream(fos);
		os.writeObject(p);
		os.close();
		os.flush();
		fos.flush();
		System.out.println("Data is serialized");
	}

}
