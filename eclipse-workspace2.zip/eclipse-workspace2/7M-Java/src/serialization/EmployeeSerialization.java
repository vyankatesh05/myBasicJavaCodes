package serialization;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class EmployeeSerialization {

	public static void main(String[] args) throws IOException {
		Employee e = new Employee(101,"Employee1");
		FileOutputStream fos = new FileOutputStream("Employee.txt");
		ObjectOutputStream os = new ObjectOutputStream(fos);
		os.writeObject(e);
		fos.close();
		os.close();
		fos.flush();
		os.flush();
	}

}
