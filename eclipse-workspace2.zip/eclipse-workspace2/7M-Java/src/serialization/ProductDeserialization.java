package serialization;
import java.io.*;
class Products implements Serializable{
	transient int product_id;
	transient String product_name;
	public Products(int product_id, String product_name) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
	}
	
}

public class ProductDeserialization {

	public static void main(String[] args) throws IOException {
		Products p = new Products(100,"Laptop");
		FileOutputStream fos = new FileOutputStream("ProductDeserialize.txt");
		ObjectOutputStream os = new ObjectOutputStream(fos);
		os.writeObject(p);
		os.close();
		os.flush();
		fos.flush();
		System.out.println("Data is Deserialized");
	}

}

