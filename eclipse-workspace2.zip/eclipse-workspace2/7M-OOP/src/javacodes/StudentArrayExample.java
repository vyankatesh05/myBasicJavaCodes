package javacodes;
import java.util.*;
public class StudentArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc  = new Scanner(System.in);
	int percentage[][] = new int[3][2];
	
	for(int i = 0; i<percentage.length; i++) {
		System.out.println("Enter percentage of student "+(i+1));
		for(int j = 0; j<percentage[j].length; j++) {
			System.out.println("Enter percentage"+(j+1)+":");
			percentage[i][j] = sc.nextInt();
		}
		System.out.println();
	}
	
	for(int i = 0; i<percentage.length; i++) {
		System.out.println("Enter percentage of student "+(i+1)+":");
		for(int j = 0; j<percentage[i].length; j++) {
			System.out.println("Subject :"+(j+1)+":"+percentage[i][j]);
			percentage[i][j] = sc.nextInt();
		}
		System.out.println();
	}
	
	}

}
