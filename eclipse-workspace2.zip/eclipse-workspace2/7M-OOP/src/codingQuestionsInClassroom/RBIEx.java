package codingQuestionsInClassroom;

interface RBI{
	float getFDInterest();
	float getsavingAccount();
	float getMFinterest();
}

class Bank implements RBI{
	public float getFDInterest() {
		return 5.6f;
	}

	@Override
	public float getsavingAccount() {
		
		return 5f;
	}

	@Override
	public float getMFinterest() {

		return 12f;
	}
}

public class RBIEx {
	public static void main(String[] args) {
		Bank bank = new Bank();
		System.out.println("FD interest: "+bank.getFDInterest()+"%");
		System.out.println("Savings account interest: "+bank.getsavingAccount()+"%");
		System.out.println("Mutual fund interest: "+bank.getMFinterest()+"%");
	}

}
