package interface01;

public interface Interface1 {

	int a = 10;
	void m1();
	void m2();
}
