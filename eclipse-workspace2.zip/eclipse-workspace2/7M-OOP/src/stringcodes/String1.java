package stringcodes;

public class String1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//M1 of string declare
		System.out.println("----m1----");
			String var1 = "ABC";
			String var2 = "ABC";
			
			if(var1 == var2) {
				System.out.println("Both strings are same");
			}
			else {
				System.out.println("Strings are not equal");
	}
			
			//M2 of string declare
			System.out.println("----m2----");
			String s1 = new String("Hello");
			
			//M3 of string declare
			char strarray[] = {'w','e','l','c','o','m','e'};
			String s2 = new String(strarray);
			
			//print both strings
			System.out.println(s1);
			System.out.println(s2);
			
			System.out.println("----m3----");
			String v1 = "Good Afternoon";
			String v2 = "Good Afternoon";
			System.out.println(v1.equals(v2));
			
			if(v1==v2)  //checking references not values 
			{
				System.out.println("Strings are equal");
			}
			else {
				System.out.println("Strings are not equal");
			}
}

}
