package stringcodes;

public class String2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//m1
		String s = "Anil";
		s.concat("giri");
		System.out.println(s); // op is = anil bcause string is immutable

		//m2
		String name = "Anil";
		name = name.concat(" Giri");
		System.out.println(name);
	}

}
