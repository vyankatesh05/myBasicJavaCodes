package encapsulation;

public class CallProduct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Product obj = new Product();
		obj.setProductID(1001);
		obj.setProductName("Mobile");
		obj.setProductPrice(25000.100f);
		
		System.out.println(obj.getProductID());
		System.out.println(obj.getProductName());
		System.out.println(obj.getProductPrice());

	}

}
