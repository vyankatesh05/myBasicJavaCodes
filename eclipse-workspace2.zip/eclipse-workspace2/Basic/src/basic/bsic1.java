package basic;

public class bsic1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		a=20;
		System.out.println(a);
		System.out.print("This is java");
	}

}
