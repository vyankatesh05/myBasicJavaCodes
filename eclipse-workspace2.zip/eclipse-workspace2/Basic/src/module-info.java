/**
 * 
 */
/**
 * @author Vyankatesh
 *
 */
module Basic {
}