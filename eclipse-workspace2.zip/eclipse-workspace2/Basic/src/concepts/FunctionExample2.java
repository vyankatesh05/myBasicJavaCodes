package concepts;

import java.util.Scanner;

public class FunctionExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FunctionExample2 fe = new FunctionExample2();
		fe.sum(44, 66);

	}
	
	void sum(int num1, int num2) {
		Scanner in = new Scanner(System.in);
		int sum = num1 + num2;
		System.out.println("Sum of number is: "+sum);
	}
}
