package concepts;
import java.util.*;
public class FunctionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FunctionExample fe = new FunctionExample();
		fe.sum();
	}
	
	void sum() {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter first number ");
		int num1 = in.nextInt();
		
		System.out.println("Enter second number ");
		int num2 = in.nextInt();
		
		int sum = num1 + num2;
		System.out.println("Sum of number is: "+sum);
	}

}
